﻿using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ThirdPartyTools;

namespace FileDataTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GivenAnyFileVersionAndSizeThenVersionAndSizeAreNumbers()
        {
            



        }
    }
}
